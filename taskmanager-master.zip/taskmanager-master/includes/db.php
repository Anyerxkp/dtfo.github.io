<?php 
$DB_HOST = '<server address>:3306';
$DB_USER = 'myadmin';
$DB_PASS = 'Password123';
$DB_NAME = 'myappdb';
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>
